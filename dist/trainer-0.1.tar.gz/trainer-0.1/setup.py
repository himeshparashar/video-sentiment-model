from setuptools import setup

setup(
    name="trainer",
    version="0.1",
    packages=["training"],
    install_requires=[],
    include_package_data=True,
    description="Training code for Vertex AI",
)
